-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 15, 2015 at 06:22 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `traffic_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `afternoon_tb`
--

CREATE TABLE IF NOT EXISTS `afternoon_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `timein` varchar(30) NOT NULL,
  `timeout` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `afternoon_tb`
--

INSERT INTO `afternoon_tb` (`id`, `fname`, `sname`, `address`, `telephone`, `date`, `timein`, `timeout`) VALUES
(1, 'ot', 'ot', 'kampala', '0987656789', '20/11/2015', '2:00 AM', '4:00 AM'),
(2, '', '', '', '', '', '', ''),
(3, '', '', '', '', '', '', ''),
(4, 'maku', 'maku', 'kampala', '0987656789', '12/12/12', '6', '8');

-- --------------------------------------------------------

--
-- Table structure for table `blue_tb`
--

CREATE TABLE IF NOT EXISTS `blue_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `plate` varchar(30) NOT NULL,
  `road` varchar(30) NOT NULL,
  `speed` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `blue_tb`
--

INSERT INTO `blue_tb` (`id`, `name`, `plate`, `road`, `speed`, `time`) VALUES
(1, 'amon', '8367', '4545', '50', '12:12'),
(2, 'moses', '4545GV', 'kampala', '90', '12:12'),
(3, 'moses', '456tb', '345', '90', '12:12');

-- --------------------------------------------------------

--
-- Table structure for table `contact_tb`
--

CREATE TABLE IF NOT EXISTS `contact_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `contact_tb`
--

INSERT INTO `contact_tb` (`id`, `name`, `address`, `telephone`, `email`, `subject`, `comment`) VALUES
(1, 'sghd', 'dfds', '0987656789', 'fdssdf', 'fdsdfg', 'dsaqwerd'),
(2, '', '', '', '', '', ''),
(3, '', '', '', '', '', ''),
(4, '', '', '', '', '', ''),
(5, '', '', '', '', '', ''),
(6, 'moses', 'kampala', '0987656789', 'makuralong@gmail.com', 'tf', 'to'),
(7, 'mm', 'kampala', '0987656789', 'makuralong@gmail.com', 'you come with .....', 'hi'),
(8, 'mm', 'kampala', '0987656789', 'makuralong@gmail.com', 'you come with .....', 'hi'),
(9, 'moses', 'kampala', '0987656789', 'makuralong@yahoo.com', 'come', 'hi'),
(10, 'moses', 'kampala', '0987656789', 'makuralong@yahoo.com', 'come', 'hi'),
(11, 'moses', 'kampala', '0987656789', 'makuralong@gmail.com', 'come', 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `data_tb`
--

CREATE TABLE IF NOT EXISTS `data_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accident` varchar(30) NOT NULL,
  `place` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `data_tb`
--

INSERT INTO `data_tb` (`id`, `accident`, `place`, `date`, `time`) VALUES
(1, 'Motorcycle accident', 'kampala', '20/11/2015', '4:00 PM'),
(2, 'Motorcycle accident', 'soroti', '20/11/2015', '5:00 PM'),
(3, '', '', '', ''),
(4, '', '', '', ''),
(5, 'Motorcycle accident', 'vvm', '4678', '6:00 PM'),
(6, 'Car accident', 'kampala', '12/12/12', '5:00 PM'),
(7, 'Motorcycle accident', 'kampala', '12/12/12', '12:00 Am'),
(8, 'Motorcycle accident', 'kampala', '12/12/12', '12:00 Am'),
(9, 'Car accident', 'kampala', '12/12/12', '12:00 Am'),
(10, 'Car accident', 'kampala', '12/12/12', '6:00 PM'),
(11, 'Car accident', 'kampala', '12/12/12', '6:00 PM'),
(12, 'Car accident', 'kampala', '12/12/12', '6:00 PM'),
(13, 'Motorcycle accident', 'kampala', '12/12/12', '12:00 Am'),
(14, 'Bicycle accident', 'kampala', '12/12/12', '10:00 AM');

-- --------------------------------------------------------

--
-- Table structure for table `evening_tb`
--

CREATE TABLE IF NOT EXISTS `evening_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `timein` varchar(30) NOT NULL,
  `timeout` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `evening_tb`
--

INSERT INTO `evening_tb` (`id`, `fname`, `sname`, `address`, `telephone`, `date`, `timein`, `timeout`) VALUES
(1, 'ot', 'ot', 'kampala', '0987656789', '20/11/2015', '2:00 AM', '4:00 AM'),
(2, '', '', '', '', '', '', ''),
(3, '', '', '', '', '', '', ''),
(4, '', '', '', '', '', '', ''),
(5, '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `map_tb`
--

CREATE TABLE IF NOT EXISTS `map_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `code` varchar(10) NOT NULL,
  `web` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `map_tb`
--

INSERT INTO `map_tb` (`id`, `car`, `email`, `code`, `web`) VALUES
(1, '', 'speed@control.com', '988774', 'www.traffic.co.ug'),
(2, '', 'makuralong@gmail.com', '256', 'www.traffic.co.ug'),
(3, '', 'makuralong@gmail.com', '256', 'www.traffic.co.ug');

-- --------------------------------------------------------

--
-- Table structure for table `morning`
--

CREATE TABLE IF NOT EXISTS `morning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `timein` varchar(30) NOT NULL,
  `timeout` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `morning`
--

INSERT INTO `morning` (`id`, `fname`, `sname`, `address`, `telephone`, `date`, `timein`, `timeout`) VALUES
(1, 'ot', 'ot', 'soroti', '0987656789', '20/11/2015', '2:00 AM', '4:00 AM'),
(2, '', '', '', '', '', '', ''),
(3, '', '', '', '', '', '', ''),
(4, '', '', 'VVVVVVVVVVVV', 'CCCCCCCCCCCC', 'BBBBBBBBBBBB', '9090', '9090'),
(5, '', '', '', '', '', '', ''),
(6, 'kjhg', 'kjhg', 'kampala', '0987656789', '30/12/12', '5', '7'),
(7, 'maku', 'maku', 'kampala', '0987656789', '30/12/12', '5', '7'),
(8, '', '', '', '', '', '', ''),
(9, 'maku', 'maku', 'kampala', '0987656789', '12/12/12', '12:12', '12:12'),
(10, 'maku', 'maku', 'kampala', '0987656789', '12/12/12', '12:12', '12:12'),
(11, '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `night_tb`
--

CREATE TABLE IF NOT EXISTS `night_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `timein` varchar(30) NOT NULL,
  `timeout` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `night_tb`
--

INSERT INTO `night_tb` (`id`, `fname`, `sname`, `address`, `telephone`, `date`, `timein`, `timeout`) VALUES
(1, 'ot', 'ot', 'kampala', '0987656789', '20/11/2015', '2:00 AM', '4:00 AM'),
(2, 'maku', 'maku', 'kampala', '0987656789', '12/12/12', '6', '8');

-- --------------------------------------------------------

--
-- Table structure for table `staff_tb`
--

CREATE TABLE IF NOT EXISTS `staff_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `web` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `staff_tb`
--

INSERT INTO `staff_tb` (`id`, `name`, `address`, `web`, `tel`, `email`) VALUES
(1, 'amon', 'kampala', 'www.traffic.co.ug', '0774606464', 'speed@control.com');

-- --------------------------------------------------------

--
-- Table structure for table `track_tb`
--

CREATE TABLE IF NOT EXISTS `track_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `car` varchar(20) NOT NULL,
  `road` varchar(20) NOT NULL,
  `web` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `track_tb`
--

INSERT INTO `track_tb` (`id`, `car`, `road`, `web`, `email`) VALUES
(1, '20', '656', 'www.traffic.co.ug', 'speed@control.com'),
(2, '4578', '5678', 'www.traffic.co.ug', 'makuralong@gmail.com'),
(3, '10', '4545', 'www.traffic.co.ug', 'makuralong@gmail.com'),
(4, '4578', '4545', 'www.traffic.co.ug', 'makuralong@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tra_tb`
--

CREATE TABLE IF NOT EXISTS `tra_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `driver` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `acc` varchar(20) NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tra_tb`
--

INSERT INTO `tra_tb` (`id`, `driver`, `address`, `tel`, `acc`, `date`, `time`) VALUES
(1, 'emmy', 'kampala', '0774606464', 'Motorcycle', '20/11/2015', '12:12');
